import json
import os
from flask import Flask, render_template, request

app = Flask(__name__)
DB_FILE = 'usuarios.json'


def cargar_db():
    if not os.path.exists(DB_FILE):
        return {} 
    with open(DB_FILE, 'r') as f:
        return json.load(f)

def guardar_db(diccionario):
    with open(DB_FILE, 'w') as f:
        json.dump(diccionario, f, indent=4)


@app.route('/')
def index():
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login():
    db = cargar_db()
    cedula = request.form.get('cedula')
    clave = request.form.get('password')
    rol = request.form.get('tipo_usuario')

    if cedula in db and db[cedula]['clave'] == clave and db[cedula]['rol'] == rol:
        return f"<h1>Bienvenido</h1><p>Entraste como {rol}.</p>"
    return "<h1>Error</h1><p>Credenciales incorrectas.</p>"


@app.route('/registrar', methods=['POST'])
def registrar():
    db = cargar_db() 
    
    cedula = request.form.get('cedula')
    clave = request.form.get('password')
    rol = request.form.get('tipo_usuario')

    db[cedula] = {
        "clave": clave,
        "rol": rol
    }
    guardar_db(db)
    
    return "<h1>Sistema Actualizado</h1><p>Los datos se guardaron en el JSON.</p>"

if __name__ == '__main__':
    app.run(debug=True)